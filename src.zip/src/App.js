import React from 'react';
import './App.css';
import Header from './componenets/layout/header'

import { BrowserRouter, Route} from "react-router-dom";
import  BubbleSort  from "./pages/bubbleSort";
// import  Sort2  from "./pages/sort2";
import Home from './pages/Home'
import D3sample from './pages/d3Sample/D3sample';
import D3sample2 from './pages/d3Sample/D3sample2';
import  Fcfs  from "./pages/fcfs";
import RoundRobin from "./pages/roundRobin"
import Tree from "./pages/treeViewer";
import PageReplacementFCFS from "./pages/FCFSPageReplacement";
import PageReplacementLRU from "./pages/LRUPageReplacement";
import PageReplacementOPT from "./pages/OPTPageReplacement";
function App() {
  return (
    <div className="App">
    <BrowserRouter>

      <Route path="/bubblesort" exact  component={BubbleSort} />
      <Route path="/d3sample"  exact  component={D3sample} />
      <Route path="/d3sample2"  exact  component={D3sample2} />
      {/* <Route path="/sort2"  exact  component={Sort2} /> */}
      <Route path="/Home" exact component={Home} />
      <Route path="/" exact component={Home} />
      <Route path="/fcfs" exact component={Fcfs}/>
      <Route path="/tree" exact component={Tree}/>
      <Route path="/fcfsPageReplacement" exact component={PageReplacementFCFS}/>
      <Route path="/lruPageReplacement" exact component={PageReplacementLRU}/>
      <Route path="/OPTPageReplacement" exact component={PageReplacementOPT}/>
      <Route path="/RoundRobin" exact component={RoundRobin}/>

    </BrowserRouter>
   
      
     
     
      
      
    </div>
  );
}

export default App;
