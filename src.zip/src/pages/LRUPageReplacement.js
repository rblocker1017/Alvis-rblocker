import React , {useState} from 'react'
import Header from "./../componenets/layout/header"
import Button from "@material-ui/core/Button"
import TextField from '@material-ui/core/TextField';
import Grid from "@material-ui/core/Grid"
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    paper: {
      padding: theme.spacing(5),
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
  }));

export default function LRUPageReplacement() {
    const classes = useStyles();    

    

    const [frames, setframes] = useState(2);
    const [input, setinput] = useState([]);
    const [displayBoolean, setDisplayBoolean] = useState(false); 
    const [answer, setAnswer] = useState([]);
    const [faultCount, setFaultcount] = useState();


    function LRUPageReplacement (pages, frames){
        let s = new Set()
        let answer = []
        let indexes = []
        let page_faults = 0; 
      
        for(let i =0; i<pages.length;i++){
          console.log("For Loop");
          if(s.size < frames){
           
            if( !s.has({...pages[i], i:i}) ){
                 s.add({...pages[i], i:i}); 
              page_faults += 1;
               let arr = {
                          column:[...s],
                          fault: "Fault"
                        }
               answer.push({
                column:[...s],
                fault: "❌"
              });
              console.log("Set: "+ arr.toString())
              indexes.push(pages[i]);
              continue; 
            }
             
          
          
          }else{
      
            if(!s.has({...pages[i], i:i})){
              let val = indexes.shift();
              s.delete(val);
              s.add({...pages[i], i:i})
              let arr = [...s]
              answer.push({
                column:[...s],
                fault: "❌ "
              });
              console.log("Set: "+ arr.toString())
              indexes.push(pages[i])
              page_faults += 1; 
              continue; 
            }
      
          }
          
          answer.push({
            column:[...s],
            fault: "✔️"
          });
          

        }
        setFaultcount(page_faults);
        return answer
      
      }  
    

    const takeInput = () =>{
    setAnswer(LRUPageReplacement(input, frames));    
    setDisplayBoolean(true); 
    console.log(answer.toString());



    }


    const tableHeader = input.map((page) =>{
      return(
      <th style={{ color: 'Green', fontSize:"30px" }} >{page}</th>


      );



    })

    const displayTable = answer.map((ans) => {
        return(<>

  <td>
        { ans.column.map((page)=>
         <tr style={{ color: 'Black', fontSize:"30px" }} >{page}</tr>
        ) }
      <p>{ans.fault}</p>
  </td>


        </>
        
        );

    })
    
    return (
        <>
          <Header  >
              <Paper className={classes.paper}>
              <h1> LRU Page Replacement </h1>
              <Grid>
            <form  noValidate autoComplete="off">
                <Grid item xs={12}>
                <Paper className={classes.paper}> 
                <TextField id="outlined-size-normal"  variant="outlined" label="Frames" onChange={(e)=>{setframes(e.target.value)}}/> 
                <TextField id="outlined-size-normal"  variant="outlined" label="Reference String " onChange={(e)=>{setinput(e.target.value.split(',').map(Number))}} />
                
                </Paper>
                
                </Grid >
                </form>
                <Button variant="contained" color= "primary" onClick={takeInput}>Run Page Replacement</Button>
                { displayBoolean ? <>
                <div style={{display: "flex", justifyContent: "center", alignItems: "center"}}>
                  
                <table       
>
                <tr>{tableHeader}</tr>
                {displayTable}
                </table>

                </div>
                
                <Typography variant="h5" gutterBottom>
                Page Faults: {faultCount}
      </Typography>
     </> : null}
            </Grid>
            
   
      
             </Paper>
            </Header>  
        </>
    )
}
