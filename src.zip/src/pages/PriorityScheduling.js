import React, { useEffect ,useState, useRef, Component} from 'react'
import * as d3  from "d3";

import {Chart} from "react-google-charts";
import Header from "./../componenets/layout/header"
import Button from "@material-ui/core/Button"
import TextField from '@material-ui/core/TextField';




export default function PriorityScheduling(props) {

const [processes, setprocesses] = useState([]) 

function PriorityScheduling(processes){
    let timeCounter =0;
    let procId = 0; 
    let answer = [  [
        { type: 'string', label: 'Task ID' },
        { type: 'string', label: 'Task Name' },
        { type: 'string', label: 'Process' },
        { type: 'date', label: 'Start Time' },
        { type: 'date', label: 'End Time' },
        { type: 'number', label: 'Duration' },
        { type: 'number', label: 'Percent Complete' },
        { type: 'string', label: 'Dependencies' },
        { type: 'int', label: 'Priority' },
    ],]


    let processList = processes; 

    processList.sort((a,b) =>
    {
        return (a.priority > b.priority) ? 1: -1
    })

    
    


    console.log(processList[0].arrivalTime)

    processList.forEach(function(i){
        console.log(i);
        answer.push([procId++,i.name,i.name,new Date(0, 0, 0, 0,0,timeCounter),new Date(0, 0, 0, 0,0,timeCounter+i.burstTime),null,100,null])
        timeCounter=timeCounter+i.burstTime;
       
    })




    return answer; 

}




const [formProcess, setformProcess] = useState()
const [formArrival, setformArrival] = useState()
const [formBurst, setformBurst] = useState()
const [displayBoolean, setDisplayBoolean] = useState(false); 




const [data, setData]  = useState( [
        [
          { type: 'string', label: 'Task ID' },
          { type: 'string', label: 'Task Name' },
          { type: 'string', label: 'Process' },
          { type: 'date', label: 'Start Time' },
          { type: 'date', label: 'End Time' },
          { type: 'number', label: 'Duration' },
          { type: 'number', label: 'Percent Complete' },
          { type: 'string', label: 'Dependencies' },
        ],
        [
          '1',
          'P1',
          'P1',
          new Date(0, 0, 0, 0,0,0),
          new Date(0, 0, 0, 0,0,0),
          null,
          100,
          null,
        ],

    
      ])

console.log("Data : " + data)
const clickInput = () =>{
    setData(fcfs(processes));
    data.forEach( i => {console.log("Data stream: "+i)} )
   setDisplayBoolean(true); 
}

    const handleAddProc = () =>{
        let temp = processes.slice(); 

        temp.push({name:formProcess , arrivalTime: parseInt(formArrival), burstTime: parseInt(formBurst), priority});
        setprocesses(temp);
        console.log(temp); 
        setDisplayBoolean(false); 
    }
    const showProceses = processes.map((proc) => {
        return(<>
          
        <p>Process: {proc.name} Arrival Time: {proc.arrivalTime} Burst Time: {proc.burstTime} </p>
        </>
        );

    })

 
    return (
        
        <Header>
         
            <h1>FCFS Gantt Chart</h1>
            
           

            <form  noValidate autoComplete="off">
        <TextField id="standard-basic" label="Process" onChange={(e)=>{setformProcess(e.target.value)}}/>
        <TextField id="standard-basic" label="Arrival Time" onChange={(e)=>{setformArrival(e.target.value)}} />
        <TextField id="standard-basic" label="Burst Time"  onChange={(e)=>{setformBurst(e.target.value)}}/>

        
            </form>
            <Button variant="contained" color = "primary" onClick={handleAddProc}>Add Process</Button>
            <Button variant="contained" color = "primary" onClick={clickInput}>Run FCFS </Button>
         { displayBoolean ? 
        <Chart
        width={'90%'}
        height={'400px'}
        chartType="Gantt"
        loader={<div>Loading Chart</div>}
        data={data}
        options={{
          height: 400,
          gantt: {
            trackHeight: 30,
            criticalPathEnabled: false
          },
          
      
        }}
        rootProps={{ 'data-testid': '1' }}
    /> : null}

<p>List of Processes</p>
{showProceses}
 </Header>
    )
}
