// import React ,{useState }from "react" 
// import {Button} from "@material-ui/core"
// import Header from '../componenets/layout/header'
// export default function Sort2(props)
// {

//     const current = [4,5,7,6,32,2]
//     const arraysOfArrays = sort2(current)
    

//     const listCurrent = arraysOfArrays.map((value) =>
//     <p>{value}</p>
//     );



//      return(
//             <div>
//                 <Header></Header>
//               {listCurrent}
              
//             </div>
//         )
    
// }    

//     function PartitionMedian(left, right)
//     {
//         let pivot = array[(int)(right + left)/2]
//         return pivot;
//     }

//     //Source code converted from
//     //https://www.geeksforgeeks.org/iterative-quick-sort/ 
//     function QuickSort(array, left, right)
//     {
//         //Create a stack to push values we're sorting onto.
//         let stack = new int[right - left + 1]

//         //Initialize the top of the stack.
//         let top = -1;

//         //Push the initial values onto the stack.
//         stack[++top] = left;
//         stack[++top] = right;

//         while(top >= 0)
//         {
//             right = stack[top--];
//             left = stack[top--];
            
//             //TODO: Use an anonymous function to set the pivot
//             pivot = PartitionMedian(left, right);

//             if(pivot - 1 > left)
//             {
//                 stack[++top] = left;
//                 stack[++top] = pivot-1;
//             }
            
//             if(pivot + 1 < right)
//             {
//                 stack[++top] = pivot + 1;
//                 stack[++top] = right;
//             }

//         }
//     }
            