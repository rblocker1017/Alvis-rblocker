import React from 'react'
import Header from '../componenets/layout/header'
export default function Home(props) {
    return (
        <div>
            <Header >
                <h1 color="secondary">
                     Home page. 
                 </h1>
      
      

      </Header>
        </div>
    )
}
