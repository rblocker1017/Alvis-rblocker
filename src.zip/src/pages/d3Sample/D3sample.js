import React, {useRef, useEffect, useState} from 'react'
import Header from '../../componenets/layout/header'
import {select} from "d3"; 

export default function D3sample(props) {
   
    const [data,setData] = useState([25, 30, 45, 60, 45, 5 ]);
    const svgRef = useRef(); 
    useEffect(()=>{
        const svg = select(svgRef.current);
        svg
            .selectAll("circle")
            .data(data)
            .join(
                enter => 
                    enter.append("circle").attr("circle", "new"),   
                  
                update => 
                    update.attr("class", "updated"), 
                    
                exit => exit.remove()
            )
    
            .attr("class", "new")
            .attr("r", value => value)
            .attr("cx", value=>value)
            .attr("stroke", "red");
        }, [data])
    
    return (
        <>
        <Header>
            
            <svg ref={svgRef} ></svg>
            <br/>
            <button onClick={ ()=> setData(data.map(value => value +5)) }>
                 Update Data</button>
       
            <button onClick={ ()=> setData(data.filter(value => value < 35)) }>
                 Exit</button>
        </Header>
        </>
    )
}
